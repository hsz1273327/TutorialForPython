def quadratic_sum(a: float, b: float) -> float:
    return a**2 + b**2
