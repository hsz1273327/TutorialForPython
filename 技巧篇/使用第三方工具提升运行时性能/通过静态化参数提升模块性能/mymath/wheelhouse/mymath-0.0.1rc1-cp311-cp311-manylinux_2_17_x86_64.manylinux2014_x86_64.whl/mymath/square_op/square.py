def square(a: float) -> float:
    return a**2