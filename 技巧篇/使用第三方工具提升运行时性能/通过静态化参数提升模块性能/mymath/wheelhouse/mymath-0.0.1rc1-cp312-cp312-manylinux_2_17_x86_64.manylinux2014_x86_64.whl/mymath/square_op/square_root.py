import math
from .square import square


def square_root(a: float) -> float:
    return math.sqrt(square(a))
